D4Demo.dpr
----------

- Needs Delphi 4 or higher

- Shows (nearly) all the properties of the SynEdit control, and all of the
  highlighters.

